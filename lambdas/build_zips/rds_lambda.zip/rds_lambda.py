import json
import pymysql

def lambda_handler(event, context):
    print(f"received event: {event}")
    obj = preprocess_incoming_event(event)

    print("nothing to see here...")
    return {
        "statusCode": 200
    }

def preprocess_incoming_event(event):
    sns_message = json.loads(event["Records"][0]["body"])
    object = json.loads(sns_message["Message"])
    return object

def parse_information(obj):
    # message = {
    #     "updatedDate": formatted,
    #     "mountain": "copper",
    #     "lifts": lifts_set,
    #     "runs": runs_set
    # }
    print(obj)